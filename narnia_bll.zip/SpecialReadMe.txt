BAJO LA LUNA PRODUCCIONES
"Narnia BLL" TrueType Font
Version 1.0. April 19, 2006

Thanks for downloading this font!

Thank you for downloading this TrueType font by Bajo la Luna Producciones. This font released and distributed as Only-For-Personal-Use Freeware (see License below).

To get the latest version of this font, visit my website at:

http://www.bajo-la-luna.com
http://gatoenlaluna.deviantart.com

---

Software License

By downloading, installing or using the archive, you confirm your agreement to this license.


I. Dedication

This font and all my hard work is dedicated to the most beautiful girl on this planet: my beloved Luna.


II. Special Freeware License

This font is released and distributed under a special Only-for-personal-use Freeware License. This means that I grant you the license to use it free of charge in ALMOST any way you want (see Terms of Use). If you like it, I ask only two things of you: say a prayer for me (and Luna while you're at it) to your God or - whatever/whoever you believe in - and wish us some luck.


III. Limitations

A. Reverse Engineering
Reverse Engineering is not allowed as with nearly any software, so this should be no surprise.

B. Warranty
Bajo La Luna Producciones gives you the only warranty that no code was placed to cause intentional harm to your system. However, I can give you no warranty that your work with my font will be uninterrupted and error-free.

C. Liability
Under no circumstances can you make me liable for any damage, however caused, including, but not limited to damage you might do to your system using my software.

D. Modifications
You may not modify, adapt, translate, decompile, disassemble, or create derivative works based on the product without prior written consent from Bajo La Luna Producciones.


IV. Terms of Use

The font is based on a registered/protected commercial logotype. This font is only for entertainment, personal and non-profit purposes. Rendering and/or production of physical goods, merchandise, media labels or advertising, creation and/or design of non-personal logotypes of any kind, including but not limited to products, companies, profit and non-profit organizations, as well as any commercial use, is strictly prohibited.

You are allowed to use this font to create graphics for your personal, non-profit website; make personal greeting cards, birthday invitations and other innocent stuff; use it for adding a nice header to your homework; and any other personal, non-profit and non-commercial use.


V. Distribution
Here are some basic rules about distributing my font.

A. Private Distribution
You may give away single copies of the software as long as you don't modify this license or other files of the archive.

B. Mirroring
If you want to mirror this font, feel free to do so as long as you don't modify the original archive. If you want to be kept up to date about major updates, check out my website. 

C. Publishing
You may publish this font in a book or magazine (or other media) by simply sending a written request for permission, including a description of your specific needs. I request only to be proper credited as the author.

If you redistribute my font in any way, I'd like you to place a link to my website or deviantART account on your website, and please drop me a line. I like to know where my fonts are ;-)


All contents of this package Copyright 2006, Bajo La Luna Producciones

If you have any questions concerning this License, or if you desire to contact Bajo La Luna Producciones for any reason, please write to:

thecat@bajo-la-luna.com

or visit us online at:

http://www.bajo-la-luna.com
http://gatoenlaluna.deviantart.com

Good luck, and blessings!
)O(The Cat)O(
Bajo La Luna Producciones
M�xico

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
BAJO LA LUNA PRODUCCIONES
Fuente TrueType "Narnia BLL"
Versi�n 1.0. Abril 19, 2006

�Gracias por descargar esta fuente!

Gracias por descargar esta fuente hecha por Bajo La Luna Producciones. Esta fuente se distribuye como freeware �nicamente para uso personal (ver Licencia). Para obtener la versi�n
m�s reciente, visita mi sitio web en:

http://www.bajo-la-luna.com
http://gatoenlaluna.deviantart.com

---

Licencia de Software

Al descargar, instalar o usar este archivo, confirmas tu aceptaci�n de esta licencia.


I. Dedicatoria

Esta fuente y todo mi trabajo est�n dedicados a la ni�a m�s hermosa de este planeta: mi adorada Luna.


II. Licencia Especial

Esta fuente se distribuye bajo una licencia especial de freeware �nicamente para uso personal. Esto significa que te otorgo la licencia para usarla CASI tanto como quieras (ver Condiciones de Uso). Si te gusta, te pido s�lo dos cosas: di una oraci�n por m� (y por Luna ya que est�s en ello) a tu Dios - o en lo que sea que creas � y des�anos algo de suerte.


III. Limitaciones

A. Ingenier�a Inversa
La Ingenier�a Inversa no est� permitida en casi cualquier software, por lo que esto no debe ser sorpresa.

B. Garant�a
Bajo La Luna Producciones te da la �nica garant�a de que no se puso ning�n c�digo para causar da�o a tu sistema. De cualquier forma, no garantizo que tu trabajo con mi fuente ser� ininterrumpido y libre de errores.

C. Responsabilidad Legal
Bajo ninguna circunstancia puedes hacerme legalmente responsable por cualquier da�o, como quiera que sea causado, incluyendo, pero no limitado a da�o que puedas hacerle a tu sistema utilizando mi software.

D. Modificaciones
No puedes modificar, adaptar, trasladar, descompilar, desensamblar o crear trabajos derivados basados en el producto sin previo consentimiento de Bajo La Luna Producciones.


IV. Condiciones de Uso

Esta  fuente est� basada en un logotipo comercial registrado. Esta fuente es �nicamente para prop�sitos personales, no lucrativos y de entretenimiento. El dise�o y producci�n de bienes materiales, mercanc�a, etiquetas de medios o publicidad, la creaci�n y/o dise�o de logotipos no personales de cualquier especie, incluyendo pero no limitado a productos, compa��as, organizaciones lucrativas y no lucrativas, as� como cualquier uso comercial, est�n estrictamente prohibidos.

Puedes utilizar esta fuente para crear gr�ficos para tu sitio personal sin fines de lucro; hacer tarjetas personales de felicitaci�n, invitaciones y otras cosas inocentes; usarlo para agregar un lindo encabezado a tus tareas; y cualquier otro uso personal, no lucrativo y no comercial.


V. Distribuci�n

Aqu� hay algunas reglas b�sicas sobre la distribuci�n de mi fuente.

A. Distribuci�n Privada
Puedes distribuir copias del software siempre que no modifiques esta licencia u otros archivos en el paquete.

B. Servidores Espejo (Mirroring)
Si quieres poner en un servidor espejo (mirroring) esta fuente, puedes hacerlo mientras no modifiques el archivo original. Si quieres informaci�n sobre actualizaciones, visita el sitio de Bajo La Luna Producciones. 

C. Publicaci�n
Puedes publicar esta fuente en un libro, revista u otro medio enviando una solicitud de permiso por escrito, incluyendo una descripci�n de tus necesidades espec�ficas. S�lo pido que me des el cr�dito como autor.

Si redistribuyes mi fuente por cualquier medio, me gustar�a que pusieras un link hacia mi sitio web o mi cuenta de deviantART, y por favor avisame. Me gusta saber d�nde est�n mis fuentes ;-)


Todo el contenido de este archivo Copyright 2006, Bajo La Luna Producciones

Si tienes alguna pregunta acerca de esta Licencia, o si deseas contactar a Bajo La Luna Producciones por cualquier raz�n, por favor escribe a:

thecat@bajo-la-luna.com

o vis�tanos en:

http://www.bajo-la-luna.com
http://gatoenlaluna.deviantart.com

Suerte, y bendiciones!
)O(The Cat)O(
Bajo La Luna Producciones
M�xico
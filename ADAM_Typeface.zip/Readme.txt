Copyright (c) 2013/14 Shrenik Ganatra.

ADAM is FREE for both personal and commercial use.

Please note that you are not allowed to sell/resell the download. Also, you may not redistribute the content of this download without my permission.

Thanks! 

- Shrenik
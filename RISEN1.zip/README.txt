Risen is a free typeface, that is free for commercial and personal use. Attribution is not required, but is appreciated. 

We would love to see what you do with Risen! Send your art along with your name and link to creativeblog@sandalschurch.com

Risen was created by Sandals Creative
Visit us online at sandalscreative.com
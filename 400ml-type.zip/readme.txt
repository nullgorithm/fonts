
---------------------
http://marcoterre.com
---------------------

TERMS OF USE:

You have the right to use the font for personal and commercial projects.

You DO NOT have the right to redistribute for free or for sale in any format without my prior consent.

You may NOT use my font in any software or apps without my prior consent.


------------------------------------------------------------------------------------------------------

http://marcoterre.com
contact@marcoterre.com

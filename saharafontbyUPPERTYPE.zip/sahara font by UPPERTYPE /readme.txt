Uppertype

USER LICENSING AGREEMENT

to fully read our license agreement

http://uppertype.net/ula.htm

YOU MAY:


1) USE THIS FONT IN COMMERCIAL DESIGN


2) USE THIS FONT IN PERSONAL DESIGN



YOU MAY NOT:


1) RE-DISTRIBUTE THIS FONT BY ANY MEANS, FOR FREE, OR FOR A FEE


2) ALTER THIS FONT FOR RE-DISTRIBUTION 

FOR ALL OTHER MATTERS,

 EMAIL me AT:

picflupu@gmail.com

or go to my web site uppertype.net


